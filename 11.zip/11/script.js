// Initialize tasks from localStorage
function getTasks() {
  return JSON.parse(localStorage.getItem('tasks')) || [];
}

// Save tasks to localStorage
function saveTasks(tasks) {
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Format date to YYYY-MM-DD
function formatDate(date) {
  const d = new Date(date);
  return d.toISOString().split('T')[0];
}

// Calculate task status using minutes (not days)
function calculateStatus(task) {
  const assignedDate = new Date(task.date);
  const dueTime = new Date(assignedDate);
  const minutes = parseInt(task.minutes || task.days || 0);

  if (!isNaN(minutes)) {
    dueTime.setMinutes(dueTime.getMinutes() + minutes);
  }

  const now = new Date();

  if (task.status === 'Finished') return 'Finished';
  if (task.status === 'Not Finished') return 'Not Finished';
  if (now > dueTime) return 'Overdue';
  return 'Pending';
}

// Export table data to Excel using SheetJS
function exportTableToExcel(tableID, filename = 'tasks.xlsx') {
  const table = document.getElementById(tableID);
  const wb = XLSX.utils.table_to_book(table);
  XLSX.writeFile(wb, filename);
}
