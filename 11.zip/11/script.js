// Initialize tasks from localStorage
function getTasks() {
  return JSON.parse(localStorage.getItem('tasks')) || [];
}

// Save tasks to localStorage
function saveTasks(tasks) {
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Format date to YYYY-MM-DD
function formatDate(date) {
  const d = new Date(date);
  return d.toISOString().split('T')[0];
}

// Calculate task status
function calculateStatus(task) {
  const dueDate = new Date(task.date);
  dueDate.setDate(dueDate.getDate() + task.days);
  const today = new Date();

  if (task.status === 'Finished') return 'Finished';
  if (today > dueDate) return 'Overdue';
  return 'Pending';
}

// Export table data to Excel
function exportTableToExcel(tableID, filename = '') {
  const table = document.getElementById(tableID);
  const workbook = XLSX.utils.table_to_book(table);
  XLSX.writeFile(workbook, filename || 'tasks.xlsx');
}
